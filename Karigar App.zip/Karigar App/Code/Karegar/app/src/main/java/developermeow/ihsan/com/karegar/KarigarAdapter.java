package developermeow.ihsan.com.karegar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by il-lsan on 11/03/16.
 */
public class KarigarAdapter extends BaseAdapter {

    Context c;

    ArrayList<String[]> all_karigar_data;
    String[] ids;
    String[] names;
    String[] addresses;
    String[] ph_nos;

    public KarigarAdapter(Context c, ArrayList<String[]> all_karigar_data) {
        this.c = c;
        this.all_karigar_data = all_karigar_data;

        ids = new String[all_karigar_data.size()];
        names = new String[all_karigar_data.size()];
        addresses = new String[all_karigar_data.size()];
        ph_nos = new String[all_karigar_data.size()];

        for (int i = 0; i < all_karigar_data.size(); i++) {
            String[] data = all_karigar_data.get(i);

            ids[i] = data[0];
            names[i] = data[1];
            ph_nos[i] = data[2];
            addresses[i] = data[3];

        }
    }

    @Override
    public int getCount() {
        return all_karigar_data.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return all_karigar_data.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        View listview = new View(c);

        LayoutInflater li = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        TextView name, add, ph, id;

        listview = li.inflate(R.layout.karigar_list_items, null);
        name = (TextView) listview.findViewById(R.id.karigar_nme);
        add = (TextView) listview.findViewById(R.id.karigar_add);
        ph = (TextView) listview.findViewById(R.id.karigar_p_no);
        id = (TextView) listview.findViewById(R.id.karigar_id);

        id.setText(ids[position] + "");
        name.setText(names[position] + "");
        add.setText(addresses[position]);
        ph.setText(ph_nos[position]);



        return listview;
    }

}
