package developermeow.ihsan.com.karegar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * Created by il-lsan on 09/03/16.
 */
public class Enter_Karegr_data extends AppCompatActivity {

    String cat;
    Spinner s;
    String[] cities = {"شہر منتخب کریں","ایبٹ آباد", "اٹک", "بنو", "مردان", "پشاور", "گلگت", "لاہور", "کراچی", "کوئٹہ", "مری"};
    DatabaseAdapter db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter_karegr);
        db = new DatabaseAdapter(this);

        Intent i  = getIntent();
       cat= i.getStringExtra("category");
        Toast.makeText(getApplicationContext(),cat,Toast.LENGTH_LONG).show();

        s = (Spinner) findViewById(R.id.city_spinner);


        // Getting all cities from database

        //citynames = db.get_all_Cities();
//        cityarraySpinner = new String[citynames.size()];
//
//        for(int x = 0; x<citynames.size();x++)
//        {
//            cityarraySpinner[x] = citynames.get(x);
//        }



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, cities);
        s.setAdapter(adapter);
    }

    //====================================================
    //====================================================
    //Button Clicks
    //====================================================

    public void Accept_Data(View v)
    {
        //validate and store data in database
        EditText name, nic, ph,address;

        name = (EditText) findViewById(R.id.karigar_name);
        ph = (EditText) findViewById(R.id.karigar_ph_no);
        address = (EditText) findViewById(R.id.karigar_address);
        nic = (EditText) findViewById(R.id.karigar_nic);

        String Name, Nic, Ph, Address, City;
        Name = name.getText().toString();
        Ph = ph.getText().toString();
        Address = address.getText().toString();
        City =  s.getSelectedItem().toString();
        Nic = nic.getText().toString();


        if(Name.isEmpty())
        {
            Toast("اپنا نام درج کریں");
        }
        else if(Nic.isEmpty())
        {
            Toast("شناختی کارڈ نمبر درج کریں");
        }
        else if(Ph.isEmpty())
        {
            Toast("فون نمبر درج کریں");
        }
        else if(Address.isEmpty())
        {
            Toast("اپنا مکمل پتا درج کریں");
        }
        else if(City.equals("شہر منتخب کریں"))
        {
           Toast("شہر منتخب کریں");
        }
        else
        {
           long no =  db.insert_Karigar_record(Name, Nic, Ph, Address, City, cat);

            if(no<0)
            {
                Toast("آپ کا اندراج نہیں ہوا");
            }
            else
            {

               Intent ii = new Intent(Enter_Karegr_data.this, ThankYou.class);
                ii.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(ii);
                finish();
            }
        }

    }

    public void Exit_Data(View v)
    {
        Intent i = new Intent(Enter_Karegr_data.this,Choose_Karegr_Category.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        finish();

    }

    //MEthod for displaying toast message

    public void Toast(String msg)
    {
        Toast.makeText(Enter_Karegr_data.this,msg,Toast.LENGTH_SHORT).show();
    }

}
