package developermeow.ihsan.com.karegar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by il-lsan on 09/03/16.
 */
public class Choose_Karegr_Category_User extends AppCompatActivity {

        String category;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.choose_karegr_category);
        }



        public void Next_Activity()
        {
            Intent i = new Intent(Choose_Karegr_Category_User.this,Select_City.class);
            i.putExtra("category", category);
            //i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);

        }

        public void Plumber(View v)
        {
            category = "plumber";
            Next_Activity();

        }
        public void Mechanic(View v)
        {
            category = "mechanic";
            Next_Activity();

        }
        public void Mistri(View v)
        {
            category = "mistri";
            Next_Activity();

        }
        public void Electrition(View v)
        {
            category = "electrition";
            Next_Activity();

        }
        public void Labor(View v)
        {
            category = "labor";
            Next_Activity();

        }
        public void Sweeper(View v)
        {
            category = "sweeper";
            Next_Activity();

        }
        public void Painter(View v)
        {
            category = "painter";
            Next_Activity();

        }
        public void Dhobi(View v)
        {
            category = "dhobi";
            Next_Activity();

        }
        public void Carpenter(View v)
        {
            category = "plumber";
            Next_Activity();

        }
        public void Gas(View v)
        {
            category = "gas";
            Next_Activity();

        }
    }


