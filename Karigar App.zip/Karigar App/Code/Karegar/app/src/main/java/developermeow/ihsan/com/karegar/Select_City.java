package developermeow.ihsan.com.karegar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * Created by il-lsan on 09/03/16.
 */
public class Select_City extends AppCompatActivity {

    String[] cities = {"شہر منتخب کریں","ایبٹ آباد", "اٹک", "بنو", "مردان", "پشاور", "گلگت", "لاہور", "کراچی", "کوئٹہ", "مری"};
    Spinner s;
    String city;
    String category;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_city);


        Intent i = getIntent();
        category= i.getStringExtra("category");

         s = (Spinner) findViewById(R.id.city_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, cities);
        s.setAdapter(adapter);

    }


    //==================================================================
    //==================================================================
    // City utton click
    //==================================================================
    public void Search_Karigar(View v)
    {

        city =  s.getSelectedItem().toString();

        if(city.equals("شہر منتخب کریں"))
        {
            Toast("شہر منتخب کریں");
        }
        else
        {
            Intent i = new Intent(Select_City.this,Show_Karigar_List.class);
            i.putExtra("city", city);
            i.putExtra("category", category);
            //i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }



    }

    public void Search_Karigar_Exit(View v)
    {
        Intent i = new Intent(Select_City.this,Choose_Karegr_Category_User.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        finish();
    }

    //MEthod for displaying toast message

    public void Toast(String msg)
    {
        Toast.makeText(Select_City.this, msg, Toast.LENGTH_SHORT).show();
    }
}
