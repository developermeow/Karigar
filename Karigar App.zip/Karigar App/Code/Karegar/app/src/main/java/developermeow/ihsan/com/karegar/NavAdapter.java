package developermeow.ihsan.com.karegar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by il-lsan on 09/03/16.
 */
public class NavAdapter extends BaseAdapter {

    Context c;
    String[] contents = {"Karigar", "User", "About Us", "Share", "Exit"};
    int[] pic = {R.mipmap.karigar, R.mipmap.user,R.mipmap.karigar, R.mipmap.user,R.mipmap.karigar};
    public  NavAdapter(Context c)
    {
        this.c=c;

    }

    @Override
    public int getCount() {
        return contents.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return contents.length;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listview = new View(c);

        LayoutInflater li = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        ImageView navicon;
        TextView navtext;

        listview = li.inflate(R.layout.layout_navigation, null);
        navtext= (TextView) listview.findViewById(R.id.nav_text);
        navicon = (ImageView) listview.findViewById(R.id.nav_icon);

        navicon.setImageResource(pic[position]);
        navtext.setText(contents[position]);


        return listview;
    }
}
