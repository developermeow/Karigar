package developermeow.ihsan.com.karegar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by il-lsan on 09/03/16.
 */
public class Show_Karigar_List extends AppCompatActivity {

    KarigarAdapter karigarAdapter;
    DatabaseAdapter db;
    String cat, city;
    ArrayList<String[]> all_karigar_data;
    TextView empty , kar_prof;
    ListView karigar_list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_karigar_list);

        Intent intent = getIntent();
        city=intent.getStringExtra("city");
        cat= intent.getStringExtra("category");
        kar_prof = (TextView) findViewById(R.id.karigar_prof);
        empty = (TextView) findViewById(R.id.empty_list);
        karigar_list = (ListView) findViewById(R.id.karigar_list);

        db = new DatabaseAdapter(this);

        kar_prof.setText(cat);


        //=======================================================
        // getting karigar items from database

        all_karigar_data = db.get_Karigars_by_City_and_Category(city, cat);


        if(all_karigar_data.size()<1)
        {
            empty.setVisibility(View.VISIBLE);
            karigar_list.setVisibility(View.GONE);
            empty.setText("اس درجے میں کوئی کاریگر میسر نہیں ہے");
        }
        else
        {
            karigarAdapter = new KarigarAdapter(Show_Karigar_List.this, all_karigar_data);
            karigar_list.setAdapter(karigarAdapter);
        }



    }
}
