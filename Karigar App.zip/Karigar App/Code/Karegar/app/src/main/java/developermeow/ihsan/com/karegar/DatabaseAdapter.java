package developermeow.ihsan.com.karegar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by il-lsan on 10/03/16.
 *
 *
 *
 */


public class DatabaseAdapter  {

    DBHelper dbHelper;
    public DatabaseAdapter(Context context)
    {
        dbHelper = new DBHelper(context);
    }

//    //------------------------
//    // get all city names
//    //------------------------
//
//    public ArrayList<String> get_all_Cities()
//    {
//        SQLiteDatabase db = dbHelper.getWritableDatabase();
//        ArrayList<String> city = new ArrayList<String>();
//
//
//
//
//        return city;
//    }

    //------------------------
    // insert karigar record
    //------------------------

    public long insert_Karigar_record(String Name, String NIC, String Ph, String Address, String City, String Profession)
    {

        SQLiteDatabase db = dbHelper.getWritableDatabase();
       // ArrayList<String> city = new ArrayList<String>();
        ContentValues contentValues = new ContentValues();


        contentValues.put(dbHelper.KARIGAR_NAME,Name);
        contentValues.put(dbHelper.KARIGAR_NIC,NIC);
        contentValues.put(dbHelper.KARIGAR_PH_NO, Ph);
        contentValues.put(dbHelper.KARIGAR_ADDRESS, Address);
        contentValues.put(dbHelper.KARIGAR_PROFESSION, Profession);
        contentValues.put(dbHelper.KARIGAR_CITY, City);

        long no_of_rows = db.insert(dbHelper.KARIGAR_TABLE,null, contentValues);



        return no_of_rows;
    }

    //------------------------
    // show  karigar record by city and category
    //------------------------

    public ArrayList<String[]> get_Karigars_by_City_and_Category(String city, String cat)
    {
        ArrayList<String[]> all_karigar_details = new ArrayList<>();
        String[] data =  new String[5];

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String[] columns = {dbHelper.KARIGAR_ID, dbHelper.KARIGAR_NAME, dbHelper.KARIGAR_NIC, dbHelper.KARIGAR_PH_NO, dbHelper.KARIGAR_ADDRESS};
        String[] selectionArgs = {city,cat};
        Cursor c = db.query(dbHelper.KARIGAR_TABLE,columns,dbHelper.KARIGAR_CITY + " = ? AND "+dbHelper.KARIGAR_PROFESSION+" = ?",selectionArgs,null,null,null);

        while (c.moveToNext())
        {
            data[0] = c.getString(c.getColumnIndex(dbHelper.KARIGAR_ID));
            data[1] = c.getString(c.getColumnIndex(dbHelper.KARIGAR_NAME));
            data[2] = c.getString(c.getColumnIndex(dbHelper.KARIGAR_PH_NO));
            data[3] = c.getString(c.getColumnIndex(dbHelper.KARIGAR_ADDRESS));
            data[4] = c.getString(c.getColumnIndex(dbHelper.KARIGAR_NIC));

            all_karigar_details.add(data);
        }

        return all_karigar_details;
    }




    //=============================================================================================================
    //=============================================================================================================
    // Database tables and constants
    //=============================================================================================================

 class DBHelper extends SQLiteOpenHelper{

     private static final String DATABASE_NAME = "Karigar.db";
     private static final String KARIGAR_ID = "name";
     private static final String KARIGAR_NAME = "id";
     private static final String KARIGAR_NIC = "nic";
     private static final String KARIGAR_PH_NO = "ph_no";
     private static final String KARIGAR_ADDRESS = "address";
     private static final String KARIGAR_PROFESSION = "profession";
     private static final String KARIGAR_CITY = "city";


     //public static final String KARIGAR_CITY = "city";
//     private static final String CITY_NAME = "c_city";
//     private static final String CITY_ID = "c_id";
//     private static final String PROFESSION = "profession";
     private static  final int DATABASE_VERSION = 1;

//     private static final String CITY_TABLE = "city_tb";
     private static final String KARIGAR_TABLE = "karigar_tb";

  //   private static final String CREATE_CITY_TAB ="CREATE TABLE "+CITY_TABLE+"("+CITY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+CITY_NAME+" VARCHAR(255));";
     private static final String CREATE_KARIGAR_TAB = "CREATE TABLE "+KARIGAR_TABLE+"("+KARIGAR_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+KARIGAR_NAME+" VARCHAR(255), "+KARIGAR_NIC+" INTEGER, "+KARIGAR_PH_NO+" INTEGER, "+KARIGAR_ADDRESS+" TEXT, "+KARIGAR_PROFESSION+" VARCHAR(255), "+KARIGAR_CITY+" VARCHAR(255));";

//     private static final String DROP_CITY_TAB = "DROP TABLE IF EXISTS "+CITY_TABLE;
     private static final String DROP_KARIGAR_TAB = "DROP TABLE IF EXISTS "+KARIGAR_TABLE;

//     private final static String CREATE_DATABASE = "";

     Context context;

     public DBHelper(Context context) {


         super(context, DATABASE_NAME, null, DATABASE_VERSION);
         this.context = context;
     }

     @Override
     public void onCreate(SQLiteDatabase db) {

         try {
             //db.execSQL(CREATE_CITY_TAB);
             db.execSQL(CREATE_KARIGAR_TAB);
         } catch (android.database.SQLException e) {
             Toast.makeText(context,e+"",Toast.LENGTH_SHORT).show();
         }

         //String[] cities = {"ایبٹ آباد", "اٹک", "بنو", "مردان", "پشاور", "گلگت", "لاہور", "کراچی", "کوئٹہ", "مری"};

//         for(int i = 0; i< cities.length; i++)
//         {
//             db.execSQL("INSERT INTO "+CITY_TABLE+" ();");
//
//         }



     }

     @Override
     public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


         try {
           //  db.execSQL(DROP_CITY_TAB);
             db.execSQL(DROP_KARIGAR_TAB);
             onCreate(db);
         } catch (SQLException e) {
             Toast.makeText(context,e+"",Toast.LENGTH_SHORT).show();
         }


     }

 }

}
